//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;
import java.util.Scanner;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.lang.Integer;
import java.util.concurrent.ThreadLocalRandom;
public class MiniGames implements ActionListener{
	String[] teamImg = {"HawksGuess.png", "CelticsGuess.png", "NetsGuess.png", "HornetsGuess.png", "BullsGuess.png"}; //All of the png images for the guessing game
	String[] teamNames = {"hawks","celtics","nets", "hornets", "bulls"}; //Names of the teams for the guessing game
	JFrame j; //Jframe
	JLabel label = new JLabel(); //Label
	JTextField text = new JTextField("Enter number here"); //Text feild for the "random number guessing game" method
	JButton enter = new JButton("Guess?"); //Button to guess for the number guessing game
	JButton make = new JButton("YOU WON"); //Button if win
	JButton miss = new JButton("YOU LOST"); //Button if loss
	int randNum = (int) (Math.random() * 10 + 1); //Random number for the random guessing game
	int randLogoNum = (int) (Math.random() * 5); //Random number for the logo and team name for the logo guessing game
	Scanner s = new Scanner(System.in); //Scanner
	JButton hardButton = new JButton("HERE!");//Buttons for the reaction time game
	JButton easyButton = new JButton("HERE!");
	long time; //time for the reaction time game 
	JButton guessItem = new JButton(); //the image for the logo guessing game
	JTextField guessLogo = new JTextField("Guess the team here");//the text box for the logo guessing game
	int myScore; //My score
	int oppScore; //opponent score
	
	public MiniGames(JFrame j){ //passing the jframe from the game class here to easily start minigames
		this.j = j;
		
		System.out.println("MiniGames loading..........");
		
		make.addActionListener(this);
		miss.addActionListener(this); //Adding action listners 
	}
	public void miniGame1(){
		//two buttons made
		//Will randomly display anywhere inbetween bounds
		//If the user clicks the button in time they win the game 
		int randXAxisHard = (int) (Math.random() * 900);
		int randYAxisHard = (int) (Math.random() * 900);
		int randXAxisEasy = (int) (Math.random() * 900);
		int randYAxisEasy = (int) (Math.random() * 900);
		hardButton.setBounds(randXAxisHard,randYAxisHard,100,100); //hard button is smaller than the easy button
		easyButton.setBounds(randXAxisEasy,randYAxisEasy,200,200);
		hardButton.addActionListener(this);
		easyButton.addActionListener(this);
		j.add(easyButton);
		j.add(hardButton); //Adding the button
		miss.addActionListener(this);
		make.addActionListener(this);
		
	}
	
	public void miniGame2(){
		//A normal number guessing game integrating the GUI
		label.setText("Guess between 1 - 10 to get points");
		label.setBounds(400,400,400,100);
		
		text.setBounds(400,100,200, 100);
		enter.setBounds(200,100, 200,100);
		enter.addActionListener(this); //Adding the action listner for the guess 
		
		j.add(label); 
		j.add(text);
		j.add(enter);
	}
	public void miniGame3(){
		ImageIcon i = new ImageIcon(teamImg[randLogoNum]); //Setting image icon to the random logo number 
		guessItem.setBounds(100,100,100,100); //Setting the bounds for the image
		guessItem.setIcon(i); //Setting the icon for the image/
		guessLogo.setBounds(100,300,300,100); //SEtting the bounds for the text feild
		guessItem.addActionListener(this);
		j.add(guessItem); //adding text feild and image
		j.add(guessLogo);
	}
	public void actionPerformed(ActionEvent e){
		
		
		if (e.getSource() == enter){ //if the user presses the enter button we parse the button
			if (Integer.parseInt(text.getText()) == randNum){ //If the user gets the correct answer then we add the make button
				make.setBounds(100,100,400,100);
				j.add(make);
				j.repaint();
				j.getContentPane().remove(label);
				j.getContentPane().remove(text); //removing previous buttons
				j.getContentPane().remove(enter);
				myScore = (int) ((Math.random() * 100) + 90);//randomizing the score you get and prining it if you win(it will be higher than the opponent)
				oppScore = (int) ((Math.random() * 60) + 40);
				System.out.println("The score was :" + myScore + " - " + oppScore);
				
				
			}
			else{//If the user gets the wrong answer then we add the miss button
				miss.setBounds(100,100,400,100);
				j.add(miss);
				j.repaint();
				j.getContentPane().remove(label);
				j.getContentPane().remove(text); //removing previous buttons
				j.getContentPane().remove(enter);
				myScore = (int) ((Math.random() * 60) + 40);//randomizing the score you get and prining it if you lose(it will be lower than the opponent)
				oppScore = (int) ((Math.random() * 100) + 90);
				System.out.println("The score was :" + myScore + " - " + oppScore);
			}
		}
		if (e.getSource() == easyButton){
			time = (System.currentTimeMillis() / 1000000000); //setting the time that they took to clickthe button
			if (time < 5000){ //If the user does it within 5 seconds then we add the "make" button 
				make.setBounds(100,100,400,100);
				j.add(make);
				j.repaint();
				j.getContentPane().remove(easyButton); //removing previous buttons
				j.getContentPane().remove(hardButton);
				myScore = (int) ((Math.random() * 100) + 90);//randomizing the score you get and prining it if you win(it will be higher than the opponent)
				oppScore = (int) ((Math.random() * 60) + 40);
				System.out.println("The score was :" + myScore + " - " + oppScore);
				
			}
			else{ //else we add the miss button 
				miss.setBounds(100,100,400,100);
				j.add(miss);
				j.repaint();
				j.getContentPane().remove(easyButton);
				j.getContentPane().remove(hardButton); //removing previous buttons 
				myScore = (int) ((Math.random() * 60) + 40);//randomizing the score you get and prining it if you lose(it will be lower than the opponent)
				oppScore = (int) ((Math.random() * 100) + 90);
				System.out.println("The score was :" + myScore + " - " + oppScore);
			}
		}
		if (e.getSource() == hardButton){
			time = (System.currentTimeMillis() / 1000000000); //SEtting the time that the user took to click the button 
			if(time < 3000){//If the user does it within 3 seconds then we add the "make" button 
				make.setBounds(100,100,400,100);
				j.add(make);
				j.repaint();
				j.getContentPane().remove(hardButton); //removing previous buttons 
				j.getContentPane().remove(easyButton);
				myScore = (int) ((Math.random() * 100) + 90);//randomizing the score you get and prining it if you win(it will be higher than the opponent)
				oppScore = (int) ((Math.random() * 60) + 40);
				System.out.println("The score was :" + myScore + " - " + oppScore);
				
			}
			else{//else we add the miss button
				miss.setBounds(100,100,400,100);
				j.add(miss);
				j.repaint();
				j.getContentPane().remove(hardButton);
				j.getContentPane().remove(easyButton); //removing previous buttons
				myScore = (int) ((Math.random() * 60) + 40);//randomizing the score you get and prining it if you lose(it will be lower than the opponent)
				oppScore = (int) ((Math.random() * 100) + 90);
				System.out.println("The score was :" + myScore + " - " + oppScore);
			
			}
			
		}
		if(e.getSource() == guessItem){
			j.getContentPane().remove(guessItem); //If the user clicks the logo then we execute this code and remove the text field and button 
			
			if (guessLogo.getText().toLowerCase().equals(teamNames[randLogoNum])){ //If the user gets it correct then we add the make button 
				make.setBounds(100,100,400,100);
				j.add(make);
				j.repaint();
				myScore = (int) ((Math.random() * 100) + 90); //randomizing the score you get and prining it if you win(it will be higher than the opponent)
				oppScore = (int) ((Math.random() * 60) + 40);
				System.out.println("The score was :" + myScore + " - " + oppScore);
			}
			else{ //If the user gets it wrong then we add the miss button 
				miss.setBounds(100,100,400,100);
				j.add(miss);
				j.repaint();
				myScore = (int) ((Math.random() * 60) + 40); //randomizing the score you get and prining it if you lose(it will be lower than the opponent)
				oppScore = (int) ((Math.random() * 100) + 90);
				System.out.println("The score was :" + myScore + " - " + oppScore);
			}
			j.getContentPane().remove(guessLogo);
		}
		if (e.getSource() == miss){ //if the user clicks the miss button then we just remove the miss button from the screen
			j.getContentPane().remove(miss);
			j.repaint();
		}
		if (e.getSource() == make){//if the user clicks the miss button then we just remove the miss button from the screen
			j.getContentPane().remove(make);
			j.repaint();
		}
		
	}
		
}