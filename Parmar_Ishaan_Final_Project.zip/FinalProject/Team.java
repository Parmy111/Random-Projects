//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;

public class Team{
	String teamName;
	int teamRating;
	public Team(String teamName, int teamRating){
		this.teamName = teamName;
		this.teamRating = teamRating;
	}

}
class Celtics extends Team{
	public Celtics(){
		super("Celtics", 93);
	}
}
class Heat extends Team{
	public Heat(){
		super("Heat", 87);
	}
}
class Lakers extends Team{
	public Lakers(){
		super("Lakers", 90);
	}
}
class Grizzlies extends Team{
	public Grizzlies(){
		super("Grizzlies", 87);
	}
}

class Warriors extends Team{
	public Warriors(){
		super("Warriors", 84);
	}
}
class SeventySixers extends Team{
	public SeventySixers(){
		super("SeventySixers", 86);
	}
}
class Cavaliers extends Team{
	public Cavaliers(){
		super("Cavaliers", 83);
	}
}
class Nuggets extends Team{
	public Nuggets(){
		super("Nuggets", 96);
	}
}
class Jazz extends Team{
	public Jazz(){
		super("Jazz", 79);
	}
}
class Knicks extends Team{
	public Knicks(){
		super("Knicks", 84);
	}
}
class Magic extends Team{
	public Magic(){
		super("Magic", 78);
	}
}
class Spurs extends Team{
	public Spurs(){
		super("Spurs", 72);
	}
}
class Angels extends Team{
	public Angels(){
		super("Angels", 90);
	}
}
class ShanghaiSharks extends Team{
	public ShanghaiSharks(){
		super("ShanghaiSharks", 90);
	}
}
class RepoReapers extends Team{
	public RepoReapers(){
		super("RepoReapers", 90);
	}
}
