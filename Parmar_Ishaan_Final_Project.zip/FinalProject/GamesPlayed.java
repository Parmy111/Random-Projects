//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;
public class GamesPlayed{
	int gamesPlayed;
	public GamesPlayed(){
		int c = 0;
	}
	public void gamesPlayed(){ //method to add games
		gamesPlayed++;
	}
	public int getGamesPlayed(){ //method to get games played
		return gamesPlayed;
	}
}