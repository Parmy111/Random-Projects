//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team
package finalproject;

public class Driver {
    public static void main(String[] args) {
		//Giving instructuons
		System.out.println("You are tasked with having to win the championship in just one season with a horribke team");
		System.out.println("The season is 82 games and you start with any amount between 70-210 million dollars to buy new players and improve the team");
		System.out.println("Remember, if you dont win the championship then your fired and can never play the game again, but if you win.... the glory is all yours");
		System.out.println("TIP: Play the first 20 games, buy players, and sim the game, otherwise winning is virtually impossibe");
		System.out.println("Extra: Some actions may be done on Windows Powershell itself so keep checking that for updates!");
		System.out.println("Extra: THERE IS A VERY COMPLEX MINIGAME AT THE END OF THE SEASON IF YOU COME TOP 2");
        Game g = new Game(); //running game 
        g.inGame();
    }
}