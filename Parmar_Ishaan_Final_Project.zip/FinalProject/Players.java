//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.util.Scanner;
import java.util.Random;
import java.lang.Integer;


public class Players{
	int rating;
	String img;
	String name;
	String pos;
	int value;
	public Players(int rating, String img, String name, String pos, int value){ //All of the nececarry informaton for the players
		this.rating = rating;
		this.img = img;
		this.name = name;
		this.value = value;
	}
}
class Lebron extends Players{ //Updating of the nececarry informaton for this player
	public Lebron(){
		super(97, "pixil-frame-0.png", "Lebron", "SF", 80000000);
	}
}
class Curry extends Players{//Updating of the nececarry informaton for this player
	public Curry(){
		super(97, "pixil-frame-1.png", "Curry", "PG", 87000000);
	}
}
class Kobe extends Players{//Updating of the nececarry informaton for this player
	public Kobe(){
		super(95, "pixil-frame-2.png", "Kobe", "SG", 63000000);
	}
}
class Jordan extends Players{//Updating of the nececarry informaton for this player
	public Jordan(){
		super(97, "MJ.png", "Jordan", "SG", 95000000);
	}
}
class Luka extends Players{//Updating of the nececarry informaton for this player
	public Luka(){
		super(93, "Luka.png", "Luka", "PG", 39000000);
	}
}
class Shaq extends Players{//Updating of the nececarry informaton for this player
	public Shaq(){
		super(95,"Shaq.png", "Shaq", "C", 45000000);
	}
}
class Harden extends Players{//Updating of the nececarry informaton for this player
	public Harden(){
		super(90, "Harden.png", "Harden", "PG", 25000000);
	}
}
class Johnson extends Players{//Updating of the nececarry informaton for this player
	public Johnson(){
		super(95, "Magic.png", "Magic", "PG", 47000000);
	}
}
class DefaultPlayer1 extends Players{ //Default players are quite bad so they have 0 value and very low rating
	public DefaultPlayer1(){
		super(70, "defaultplayer.png", "default", "NA", 0000000);
	}
}
class DefaultPlayer2 extends Players{//Default players are quite bad so they have 0 value and very low rating
	public DefaultPlayer2(){
		super(70, "defaultplayer.png", "default", "NA", 0000000);
	}
}
class DefaultPlayer3 extends Players{//Default players are quite bad so they have 0 value and very low rating
	public DefaultPlayer3(){
		super(70, "defaultplayer.png", "default", "NA", 0000000);
	}
}
class DefaultPlayer4 extends Players{//Default players are quite bad so they have 0 value and very low rating
	public DefaultPlayer4(){
		super(70, "defaultplayer.png", "default", "NA", 0000000);
	}
}
class DefaultPlayer5 extends Players{//Default players are quite bad so they have 0 value and very low rating
	public DefaultPlayer5(){
		super(70, "defaultplayer.png", "default", "NA", 0000000);
	}
}