//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;
//Importing elements for GUI and other codes
import javax.swing.*;
import java.awt.event.*;
import java.awt.Color;
import java.util.Scanner;
import java.util.Random;
import java.lang.Integer;
import java.util.ArrayList;

public class Game implements ActionListener {
    String s; 
    JFrame f = new JFrame(); //Frame used throughout the game
	String gameName; //game Name
	
	JButton b = new JButton("Press Here for Transfer Market"); //Main button 1
	JButton b2 = new JButton("Press Here for Calendar");//Main button 2
	JButton b3 = new JButton("Press Here for Endorsements");//Main button 3
	JButton sim = new JButton("Want to sim game?");//Main Button 4
	JButton playGame = new JButton("Want to play game?"); //Main Button 5
	Scanner sc = new Scanner(System.in); //Scanner object
	GamesPlayed gp = new GamesPlayed(); //Importing class where I store the games played
	int losses = 0; //Calculating losses
	int points; //Calculating wins
	JLabel tip = new JLabel();
	int cash =  (int)(Math.random() * 140000000) + 70000000; //The amount of cash you get to start your season.
	JLabel background=new JLabel("here");//Background image 
	//Transfer Market
	ArrayList<JButton> myTeam = new ArrayList<JButton>(); //Arraylist of buttons used to store the button that the player is on so that you can see the "view team" area clearly
	ArrayList<Players> myTeam2 = new ArrayList<Players>(); //Arraylist of players helping me calculate things such as my team rating and what the names of the players are
	Players[] players = new Players[] {new DefaultPlayer1(), new DefaultPlayer2(), new DefaultPlayer3(), new DefaultPlayer4(), new DefaultPlayer5(), new Lebron(), new Curry(), new Kobe(), new Jordan(), new Luka(), new Shaq(), new Harden(), new Johnson()};
	//All of the players are stored in this array for easy access
	JButton view1 = new JButton("Do you want to view your team??"); //This button is used to ask if you want to see the team 
	JButton view2 = new JButton("Do you want to buy a player off the market??"); //This button is used to ask the user if they want to buy something off the market
	
	//This is all of the images being made for all of the players
	ImageIcon image1 = new ImageIcon(players[5].img);
	ImageIcon image2 = new ImageIcon(players[6].img);
	ImageIcon image3 = new ImageIcon(players[7].img);
	ImageIcon image4 = new ImageIcon(players[8].img);
	ImageIcon image5 = new ImageIcon(players[9].img);
	ImageIcon image6 = new ImageIcon(players[10].img);
	ImageIcon image7 = new ImageIcon(players[11].img);
	ImageIcon image8 = new ImageIcon(players[12].img);
	//Default image set for the first 5 players that you start with.
	ImageIcon defaultimg = new ImageIcon("defaultplayer.png");

	//There are all the buttons for the players, used for easy display.
	JButton TF1 = new JButton(image1);
	JButton TF2 = new JButton(image2);
	JButton TF3 = new JButton(image3);
	JButton TF4 = new JButton(image4);
	JButton TF5 = new JButton(image5);
	JButton TF6 = new JButton(image6);
	JButton TF7 = new JButton(image7);
	JButton TF8 = new JButton(image8);
	JButton default1 = new JButton(defaultimg);
	JButton default2 = new JButton(defaultimg);
	JButton default3 = new JButton(defaultimg);
	JButton default4 = new JButton(defaultimg);
	JButton default5 = new JButton(defaultimg);
	
	JButton exit = new JButton("Exit"); //Button used if the user doesnt want to see his team anymore
	//TransferMarket
	
	//Calendar
	Team[] calendar = new Team[82]; //This is the place where we access all of the teams in the calendar that we have.
	Team[] randomTeams = new Team[] {new Celtics(), new Heat(), new Lakers(), new Grizzlies(), new Warriors(), new SeventySixers(), new Cavaliers(), new Nuggets(), new Jazz(), new Knicks(), new Magic(), new Spurs(), new Angels(), new ShanghaiSharks(), new RepoReapers()};
	//This array stores all of the teams for easy access 
	
	//All of the buttons used to play game 
	JButton gameOne = new JButton();
	JButton gameTwo = new JButton();
	JButton gameThree = new JButton();
	JButton gameFour = new JButton();
	JButton gameFive = new JButton();
	JButton gameSix = new JButton();
	JButton gameSeven = new JButton();
	//Calendar
	
	//GameSim
	JButton win = new JButton(); //If win
	JButton loss = new JButton(); //If loss
	JButton win2 = new JButton(); //If win 2
	JButton loss2 = new JButton(); //If loss 2
	//GameSim
	//Endorsements
	//All of the buttons and image icons for the Endorsements that my game has
	ImageIcon adidas = new ImageIcon("Adidas.png");
	ImageIcon nike = new ImageIcon("Nike.png");
	ImageIcon NB = new ImageIcon("NB.png");
	JButton e1 = new JButton(adidas);
	JButton e2 = new JButton(nike);
	JButton e3 = new JButton(NB);
	int totalEnorsments; //used to check if you have less than 6 endorsements, if you have more it doesnt allow you to get more
	
    public Game() {
        s = this.s;
        String[] start = { "Tactic", "Squad", "Vibrant", "Radiant", "Brave", "Seam" };
        String[] finish = { "GOAT", "Builder", "Formations", "Strategy", "Transfers" };

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int m = random.nextInt(start.length - 1);
        int c = random.nextInt(finish.length - 1);
        gameName = start[m] + finish[c];
		System.out.println(gameName);
		
		//Adding all of the default players to the 2nd array for names and ratings.
		myTeam2.add(players[0]);
		myTeam2.add(players[1]);
		myTeam2.add(players[2]);
		myTeam2.add(players[3]);
		myTeam2.add(players[4]);
		
		//Adding default players to the first array for viewing.
		myTeam.add(default1);
		myTeam.add(default2);
		myTeam.add(default3);
		myTeam.add(default4);
		myTeam.add(default5);
		
		
		//Endorsements action listeners
		e1.addActionListener(this);
		e2.addActionListener(this);
		e3.addActionListener(this);
		
		//making the calendar that you are going to play here
		for (int i = 0; i < 82; i++){
			int randomTeam = (int) (Math.random() * 14);
			calendar[i] = randomTeams[randomTeam];
		}
		
	}
		
	public void GameMenu(){
		
		//Menu for the game that remains on the right side of the screen the whole game.
		playGame.setBounds(1200,100,300,100);
		b.setBounds(1200,200,300,100);
		sim.setBounds(1200,300,300,100);
        b2.setBounds(1200,400,300,100);
		b3.setBounds(1200,500,300,100);
		tip.setText("MAKE SURE TO BE CHECKING POWERSHELL EVER SO OFTEN ONG ONG FR");
		tip.setBounds(100,100,500,100);
		f.add(tip);
		//Adding all the main buttons and other such items.
		
        f.add(b);
		f.add(sim);
		f.add(playGame);
		f.add(b2);
		f.add(b3);
		
        f.setSize(1700, 1300);
		b.addActionListener(this);
		sim.addActionListener(this);
		playGame.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		f.setLayout(null);
        f.setVisible(true);
	}
	
	//TransferMarket
	public void TransferMarket(){
		Scanner s = new Scanner(System.in); //Adding scanner
		System.out.println("What player do you want to buy? You can choose from: MJ, Lebron, Kobe, Curry, Luka, Shaq, Harden, or Magic"); //Choose between some the players to buy 
		System.out.println("enter exit to exit");
		String option1 = s.nextLine();
		option1 = option1.toLowerCase();
		
		
		System.out.println(cash);
		//Printing the amount of cash you have
		
		if ((option1.equals("mj"))){ //If user types MJ then the user gets him only if their cash is greater then the value of the player
			if(cash > players[8].value){
				myTeam.remove(0); //removing the first player
				myTeam.add(TF8); //Adding the button that pertains to MJ
				myTeam2.remove(0); //Removing the first player from the 2nd array
				myTeam2.add(players[8]); //Adding the MJ object to myTeam2
				cash = cash - players[8].value; //subtracting cash
				System.out.println(cash); //printing value
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("kobe"))){
			if(cash > players[7].value){
				myTeam.remove(0);
				myTeam.add(TF3);
				myTeam2.remove(0);
				myTeam2.add(players[7]);
				cash = cash - players[7].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("curry"))){
			if(cash > players[6].value){
				myTeam.remove(0);
				myTeam.add(TF2);
				myTeam2.remove(0);
				myTeam2.add(players[6]);
				cash = cash - players[6].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("lebron"))){
			if(cash > players[6].value){
				myTeam.remove(0);
				myTeam.add(TF1);
				myTeam2.remove(0);
				myTeam2.add(players[6]);
				cash = cash - players[6].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("luka"))){
			if(cash > players[9].value){
				myTeam.remove(0);
				myTeam.add(TF5);
				myTeam2.remove(0);
				myTeam2.add(players[9]);
				cash = cash - players[9].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("shaq"))){
			if(cash > players[10].value){
				myTeam.remove(0);
				myTeam.add(TF6);
				myTeam2.remove(0);
				myTeam2.add(players[10]);
				cash = cash - players[10].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		//Same thing is done for the other 10 players on this list.
		else if ((option1.equals("harden"))){
			if(cash > players[11].value){
				myTeam.remove(0);
				myTeam.add(TF7);
				myTeam2.remove(0);
				myTeam2.add(players[11]);
				cash = cash - players[11].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		else if ((option1.equals("magic"))){
			if(cash > players[12].value){
				myTeam.remove(0);
				myTeam.add(TF8);
				myTeam2.remove(0);
				myTeam2.add(players[12]);
				cash = cash - players[12].value;
				System.out.println(cash);
			}
			else{
				System.out.println("Cant Buy");
			}
		}
		else if(option1.equals("exit")){
			System.out.println("exited");
		}
		else{
			System.out.println("Invalid Input");
		}
		
	}
	public void TransferView(){
		//First, when the transfermarket button is clicked then it will ask the user whether or not they want to see their team or buy a player.
		view1.setBounds(100,100,400,50);
		view2.setBounds(100,150,400,50);
		f.add(view1);
		f.add(view2);
		view1.addActionListener(this);
		view2.addActionListener(this);
		
		exit.addActionListener(this);
	}
	//This is the code the runs the final standings for all of the teams
	public void points(){
		int[] teamOverallPoints = new int[16];
		int celticsOverall = (int) (Math.random() * 78); //Celtics overall points is higher than the magic because the celtics have a higher rating than them 
		teamOverallPoints[0] = celticsOverall;
		//Randomizing all of the wins and losses throughout the season
		int heatOverall = (int) (Math.random() * 75);
		teamOverallPoints[1] = heatOverall;
		//Randomizing all of the wins and losses throughout the season
		int lakersOverall = (int) (Math.random() *  80);
		teamOverallPoints[2] = lakersOverall;
		//Randomizing all of the wins and losses throughout the season
		int grizzliesOverall = (int) (Math.random() * 54);
		teamOverallPoints[3] = grizzliesOverall;
		//Randomizing all of the wins and losses throughout the season
		int warriorsOverall = (int) (Math.random() * 64);
		teamOverallPoints[4] = warriorsOverall;
		//Randomizing all of the wins and losses throughout the season
		int sixersOverall = (int) (Math.random() *  62);
		teamOverallPoints[5] = sixersOverall;
		//Randomizing all of the wins and losses throughout the season
		int cavsOverall = (int) (Math.random() * 56);
		teamOverallPoints[6] = cavsOverall;
		//Randomizing all of the wins and losses throughout the season
		int nuggets = (int) (Math.random() * 80);
		teamOverallPoints[7] = nuggets;
		//Randomizing all of the wins and losses throughout the season
		int jazz = (int) (Math.random() * 54);
		teamOverallPoints[8] = jazz;
		//Randomizing all of the wins and losses throughout the season
		int knicks = (int) (Math.random() * 50);
		teamOverallPoints[9] = knicks;
		//Randomizing all of the wins and losses throughout the season
		int magic = (int) (Math.random() * 48);
		teamOverallPoints[10] = magic;
		//Randomizing all of the wins and losses throughout the season
		int spurs = (int) ((Math.random() * 43));
		teamOverallPoints[11] = spurs;
		//Randomizing all of the wins and losses throughout the season
		int angels = (int) (Math.random() * 64);
		teamOverallPoints[12] = angels;
		//Randomizing all of the wins and losses throughout the season
		int shanghai = (int) (Math.random() * 71);
		teamOverallPoints[13] = shanghai;
		//Randomizing all of the wins and losses throughout the season
		int reporeapers = (int) (Math.random() * 70);
		teamOverallPoints[14] = reporeapers;
		//Randomizing all of the wins and losses throughout the season
		teamOverallPoints[15] = points; //Adding the amount of points you get to the array that stores them
		for(int i = (teamOverallPoints.length-  1); i > 0; i--){ //Sorting the teams scores, if a team has 42 wins and another has 80 wins then it will swap their positions
			for(int j = i - 1; j > 0; j--){
				if (teamOverallPoints[i] < teamOverallPoints[j]){
					int temp = teamOverallPoints[i];
					teamOverallPoints[i] = teamOverallPoints[j];
					teamOverallPoints[j] = temp;
				}
			}
		}
		        
		for(int i = (teamOverallPoints.length-  1); i > 0; i--){ //Printing out all of the team scores at the end of the season.
			System.out.println(teamOverallPoints[i] + " - " + (82 - teamOverallPoints[i]) + " was a record at the end of the season.");
		}
		System.out.println(points + " - " + losses + " was your record at the end of the season."); //printing the users team score at the end of the season
		if (teamOverallPoints[14] == points || teamOverallPoints[15] == points){ //IF you are within the top 2 then you can compete for the championship with the FINALBASKETBALLGAME minigame. 
		//The reason that I didnt use this minigame in the other minigames is because the finals/playoffs are much more exciting than the regular season so I just wanted to signify that.
			System.out.println("ITS GAME TIME >:), IF YOU SEE THE CHAMPIONSHIP TROPHY YOU WON! IF YOU WIN THEN YOUR THE GREATEST MANAGER OF ALL TIME!"); //Giving you information on whats happening
			FinalBasketballGame finalgame = new FinalBasketballGame(); //Running the fonals minigame
		}
		else{
			System.out.println("YOU LOST! YOU HAVE BEEN FIRED AS THE MANAGER AND CAN NEVER COME BACK >:("); //If your aren't in the top 2 then you lose
		}
	}
	public void Calender(){
		
		if (gp.getGamesPlayed() < 75){ //Making the amount of games visable as 75 max because if it goes any higher then a out of bounds exception will occur
			gameOne.setText("Your next game is against : " + calendar[gp.getGamesPlayed()].teamName + " their rating is : " + calendar[gp.getGamesPlayed()].teamRating);
			gameOne.setBounds(100,280,500,50); //Setting the bounds and text for the games
			gameTwo.setText("Your " + (gp.getGamesPlayed() + 1) + " game is against : " + calendar[gp.getGamesPlayed() + 1].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 1].teamRating);
			gameTwo.setBounds(100,250,500,50);//Setting the bounds and text for the games
			gameThree.setText("Your " + (gp.getGamesPlayed() + 2) + " game is against : " + calendar[gp.getGamesPlayed() + 2].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 2].teamRating);
			gameThree.setBounds(100,220,500,50);//Setting the bounds and text for the games
			gameFour.setText("Your " + (gp.getGamesPlayed() + 3) + " game is against : " + calendar[gp.getGamesPlayed() + 3].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 3].teamRating);
			gameFour.setBounds(100,190,500,50);//Setting the bounds and text for the games
			gameFive.setText("Your " + (gp.getGamesPlayed() + 4) + " game is against : " + calendar[gp.getGamesPlayed() + 4].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 4].teamRating);
			gameFive.setBounds(100,160,500,50);//Setting the bounds and text for the games
			gameSix.setText("Your " + (gp.getGamesPlayed() + 5) + " game is against : " + calendar[gp.getGamesPlayed() + 5].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 5].teamRating);
			gameSix.setBounds(100,130,500,50);//Setting the bounds and text for the games
			gameSeven.setText("Your " + (gp.getGamesPlayed() + 6) + " game is against : " + calendar[gp.getGamesPlayed() + 6].teamName + " their rating is : " + calendar[gp.getGamesPlayed() + 6].teamRating);
			gameSeven.setBounds(100,100,500,50);//Setting the bounds and text for the games
			exit.setBounds(100,330,100,100);
			f.add(exit);
		}
		//Setting action listeners for the games
		gameOne.addActionListener(this);
		gameTwo.addActionListener(this);
		gameThree.addActionListener(this);
		gameFour.addActionListener(this);
		gameFive.addActionListener(this);
		gameSix.addActionListener(this);
		gameSeven.addActionListener(this);
		exit.addActionListener(this);
		//Adding the games when calender is displayed
		f.add(gameOne);
		f.add(gameTwo);
		f.add(gameThree);
		f.add(gameFour);
		f.add(gameFive);
		f.add(gameSix);
		f.add(gameSeven);
		f.repaint();
	}
	public int teamRating(){ //Method to get team rating
		int rating = (myTeam2.get(0)).rating + (myTeam2.get(1)).rating + (myTeam2.get(2)).rating + (myTeam2.get(3)).rating + (myTeam2.get(4)).rating;
		rating = rating/5;
		return rating;
	}
	public int ratingOfGame(){ //Method to get rating of the team your playing against
		int rating = (calendar[gp.getGamesPlayed()].teamRating);
		return rating;
	}
	public String nameOfTeam(){ //Method to get the name of the team.
		String name = calendar[gp.getGamesPlayed()].teamName;
		return name;
	}
	public void GameSim(){ //Game sim method
		if (teamRating() < ratingOfGame()){
			int myScoreWorse = (int) (Math.random() * 100 + 70); //If you have a lower rating then you have a lower chance to win, hence the oppScoreWorse being higher than my score
			int oppScoreWorse = (int) (Math.random() * 120 + 80);
			if (myScoreWorse > oppScoreWorse){
				System.out.println("You won the game against " + nameOfTeam());
				points++; //If you win then you get the point
				
			}
			else{
				System.out.println("You lost the game against " + nameOfTeam());
				losses++; //If you lose then we add the losses
			}
			System.out.println(myScoreWorse + " - " + oppScoreWorse + " was the score."); //Printing score of the game
		}
		else if (teamRating() > ratingOfGame()){
			int myScoreBetter = (int) (Math.random() * 120 + 90);
			int oppScoreBetter = (int) (Math.random() * 100 + 70);//If you have a higher rating then you have a lower chance to win, hence the oppScoreBetter being lower than my score
			if (myScoreBetter > oppScoreBetter){
				System.out.println("You won the game against " + nameOfTeam()); //If you win we add the points
				
				points++;
			}
			else{
				System.out.println("You lost the game against " + nameOfTeam());
				losses++; //If you lose we add the losses
			}
			System.out.println(myScoreBetter + " - " + oppScoreBetter + " was the score."); //Pringing score of the game
		}
		else{
			System.out.println("error"); //If it doesnt work then we print error
		}
		
	}
	
    public void inGame() {
		GameMenu(); //Just a extra class so that no errors occur
    }
	public void actionPerformed(ActionEvent e){
		
		
		if (e.getSource() == b){
			TransferView();
			f.repaint(); //If the user chooses the trnsfer market button then it prints the transfer view method
		}
		
		if (e.getSource() == b2){
			Calender(); // If the user chooses the calendar 
		}
		if (e.getSource() == b3){ //If the user chooses to get endorsements then it checks if you have more than 10 wins and less than 5 total endorsements
			if (points >= 10 && (totalEnorsments <= 5)){
				
				//Then we add the 3 different endorsements that you can have. 
				e1.setBounds(100,100,100,100);
				e2.setBounds(100,200,100,100);
				e3.setBounds(100,300,100,100);
				f.add(e1);
				f.add(e2);
				f.add(e3);
				f.repaint(); //repainting
			}
			else{
				System.out.println("Can't get endorsements yet"); //If you cant get and endorsements then it just prints that you cant
			}
		}
		if(e.getSource() == sim){ //If the user chooses the sim game button then we run the sim game method
			GameSim();
			gp.gamesPlayed(); //Running the method to add the games played total
			cash = cash + 6000000; //Adding the cash because you get a certain amount every game.
			f.repaint(); //repainting 
		}
		if(e.getSource() == playGame){ //If they want to play the game then they get a random game between 3 games
			MiniGames mini = new MiniGames(f);
			int rand = (int) (Math.random() * 3 + 1); //Randomizing the minigame that the user will play
			if (rand == 1){ //If the rand num is 1 then it will run the first minigame
				mini.miniGame1();
				
			}
			else if(rand == 2){//If the rand num is 2 then it will run the second minigame
				mini.miniGame2();
				
			}
			else{ //else it just runs the 3rd minigame
				mini.miniGame3();
				
			}
			points++; //Adding if game won
			gp.gamesPlayed(); //Adding the amount of games played
			f.repaint(); //repainting
			cash = cash + 6000000;//Adding the cash because you get a certain amount every game.
		}
		//Transfer Market Action Listeners
		if (e.getSource() == view2){ //If the user chooses to buy a player then it runs the transfermarket method
			TransferMarket();
			tip.setText("Go to the operating system for this");
			tip.setBounds(400,800,200,50);
			f.add(tip);
			f.getContentPane().remove(view1); //removing the 2 previous bittons
			f.getContentPane().remove(view2);
			f.repaint(); //repainting
		}
		if (e.getSource() == view1){ //If the user chooses to view his team then we add the buttons for his team.
			//Getting all of the users current team buttons and setting bounds 
			(myTeam.get(0)).setBounds(100,50,100,100); 
			(myTeam.get(1)).setBounds(100,120,100,100);
			(myTeam.get(2)).setBounds(100,190,100,100);
			(myTeam.get(3)).setBounds(100,260,100,100);
			(myTeam.get(4)).setBounds(100,330,100,100);
			exit.setBounds(100,600,100,100); //this button is used to exit the view player method
			//Adding all of the players and exit button to the frame
			f.add((myTeam.get(0)));
			f.add((myTeam.get(1)));
			f.add((myTeam.get(2)));
			f.add((myTeam.get(3)));
			f.add((myTeam.get(4)));
			f.add(exit); 
			f.getContentPane().remove(view1);
			f.getContentPane().remove(view2); //removing two previous buttons
			f.repaint();
			
		}
		
		
		
		if (e.getSource() == exit){ //If the user chooses to exit then it removes all of the users current team buttons
			f.getContentPane().remove(exit);
			f.getContentPane().remove(myTeam.get(0));
			f.getContentPane().remove(myTeam.get(1));
			f.getContentPane().remove(myTeam.get(2));
			f.getContentPane().remove(myTeam.get(3));
			f.getContentPane().remove(myTeam.get(4));
			f.repaint();
		}
		//end 
		//Start of Calender Action Listners
		if (e.getSource() == exit){ //If the user chooses the first game that he is playing then we just remove all of the calender games
			f.getContentPane().remove(gameOne);
			f.getContentPane().remove(gameTwo);
			f.getContentPane().remove(gameThree);
			f.getContentPane().remove(gameFour);
			f.getContentPane().remove(gameFive);
			f.getContentPane().remove(gameSix);
			f.getContentPane().remove(gameSeven);
			f.repaint();
		}
		//end
		
		if(e.getSource() == e1){ //If the user chooses the first endorsement then we add 10 million to the balance, add the totalEnorsments count, 
		//and remove all of the previous buttons as well as print the users new amount of cash
			f.getContentPane().remove(e1);
			f.getContentPane().remove(e2);
			f.getContentPane().remove(e3);
			cash = cash + 10000000;
			totalEnorsments++;
			f.repaint();
			System.out.println(cash);
		}
		
		if(e.getSource() == e2){ //If the user chooses the second endorsement then we add 10 million to the balance, add the totalEnorsments count, 
		//and remove all of the previous buttons as well as print the users new amount of cash
			f.getContentPane().remove(e1);
			f.getContentPane().remove(e2);
			f.getContentPane().remove(e3);
			cash = cash + 10000000;
			totalEnorsments++;
			f.repaint();
			System.out.println(cash);
		}
		if(e.getSource() == e3){ //If the user chooses the third endorsement then we add 10 million to the balance, add the totalEnorsments count, 
		//and remove all of the previous buttons as well as print the users new amount of cash
			f.getContentPane().remove(e1);
			f.getContentPane().remove(e2);
			f.getContentPane().remove(e3);
			cash = cash + 10000000;
			totalEnorsments++;
			f.repaint();
			System.out.println(cash);
		}
		if (gp.gamesPlayed == 82){ //If the user reaches the 82 game mark then we remove everything from the content pane and use the points class(the finals game as well as the standings and other such commodities).
			f.getContentPane().removeAll();
			points();
		}
		ImageIcon back = new ImageIcon("cropped_GettyImages-1388455508.png"); //Adding the background after the buttons are clicked because it helps the users actually see the background
		background.setIcon(back);
		background.setBounds(100,-300,1700,1300);
		f.add(background);
		f.remove(tip); //removing the tip from the game
	}
}
