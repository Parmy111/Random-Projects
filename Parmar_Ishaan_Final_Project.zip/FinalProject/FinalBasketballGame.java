//Done by Ishaan Parmar on 5/20/2023 to make a program that lets you be a manager for your own basketball team

package finalproject;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class FinalBasketballGame extends JFrame implements ActionListener {

    // Declare some constants
    public static final int WIDTH = 600;
    public static final int HEIGHT = 400;
    public static final int SPEED = 10;
    public static final int BALL_SIZE = 20;
    public static final int HOOP_SIZE = 100;
    public static final int GRAVITY = 1;

    // Declare some variables
	private ImageIcon CHIPWIN = new ImageIcon("NBA_LOB_Trophy_2022.png");
	private JButton chipwin = new JButton(CHIPWIN);
    private JPanel panel;
    private JLabel scoreLabel;
    private JButton startButton;
    private Timer timer;
    private Random random;
    private int score;
    private int bx, by; // coordinates of the ball
    private int vx, vy; // velocity of the ball
    private int hx, hy; // coordinates of the hoop
    private boolean shooting; // flag to indicate if the ball is in motion
	int randScore = (int) (Math.random() * 30 + 20);

    // Constructor
    public FinalBasketballGame() {
        // Set up the frame
		
        super("BasketballGame");
		System.out.println("HIT THE BASKET(THE BOX) WITH THE RED DOT(THE BASKETBALL) AS MANY TIMES AS YOU CAN! IF YOU WIN YOU WIN THE CHAMPIONSHIP!!!");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);

        // Create and add the panel
        panel = new JPanel();
        panel.setLayout(null);
        panel.setBackground(Color.WHITE);
        add(panel);

        // Create and add the score label
        scoreLabel = new JLabel("Score: 0");
        scoreLabel.setBounds(10, 10, 100, 20);
        panel.add(scoreLabel);

        // Create and add the start button
        startButton = new JButton("Start");
        startButton.setBounds(WIDTH / 2 - 50, HEIGHT / 2 - 25, 100, 50);
        startButton.addActionListener(this);
        panel.add(startButton);

        // Create the timer
        timer = new Timer(1000 / SPEED, this);

        // Create the random object
        random = new Random();

        // Initialize the score
        score = 0;

        // Initialize the ball and hoop coordinates
        bx = WIDTH / 2 - BALL_SIZE / 2;
        by = HEIGHT - BALL_SIZE;
        hx = random.nextInt(WIDTH - HOOP_SIZE);
        hy = random.nextInt(HEIGHT / 2 - HOOP_SIZE) + HOOP_SIZE;

        // Initialize the ball velocity and shooting flag
        vx = vy = 0;
        shooting = false;

        // Make the frame visible
        setVisible(true);
    }

    // Action listener method
    public void actionPerformed(ActionEvent e) {
        // If the start button is clicked, start the game
        if (e.getSource() == startButton) {
            startButton.setVisible(false);
            timer.start();
            panel.requestFocus();
            panel.addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    shootBall(e);
                }
            });
            panel.addMouseMotionListener(new MouseMotionAdapter() {
                public void mouseMoved(MouseEvent e) {
                    moveBall(e);
                }
            });
		}

        // If the timer is running, update the game logic
        if (e.getSource() == timer) {
            updateBall();
            checkCollision();
			checkWin();
            repaint();
        }
    }

    // Method to move the ball according to the mouse position
    public void moveBall(MouseEvent e) {
        // If the ball is not shooting, set its position to the mouse position
        if (!shooting) {
            bx = e.getX() - BALL_SIZE / 2;
            by = e.getY() - BALL_SIZE / 2;

            // Keep the ball within the bounds of the panel
            if (bx < 0) bx = 0;
            if (by < 0) by = 0;
            if (bx > WIDTH - BALL_SIZE) bx = WIDTH - BALL_SIZE;
            if (by > HEIGHT - BALL_SIZE) by = HEIGHT - BALL_SIZE;
        }
    }

    // Method to shoot the ball according to the mouse click
    public void shootBall(MouseEvent e) {
        // If the ball is not shooting, set its velocity and shooting flag
        if (!shooting) {
            vx = e.getX() - bx - BALL_SIZE / 2;
            vy = e.getY() - by - BALL_SIZE / 2;
            shooting = true;
        }
    }

    // Method to update the ball position and velocity
    public void updateBall() {
        // If the ball is shooting, apply gravity and move it
        if (shooting) {
            vy += GRAVITY;
            bx += vx;
            by += vy;

            // Bounce the ball off the edges of the panel
            if (bx < 0 || bx > WIDTH - BALL_SIZE) {
                vx = -vx;
            }
            if (by < 0 || by > HEIGHT - BALL_SIZE) {
                vy = -vy;
            }
        }
    }

    // Method to check if the ball collides with the hoop
    public void checkCollision() {
        // If the ball is shooting and its center is within the hoop, score a point
        if (shooting && bx + BALL_SIZE / 2 > hx && bx + BALL_SIZE / 2 < hx + HOOP_SIZE && by + BALL_SIZE / 2 > hy && by + BALL_SIZE / 2 < hy + HOOP_SIZE) {
            // Increase the score and update the label
            score++;
            scoreLabel.setText("Score: " + score);

            // Move the hoop to a new random location
            hx = random.nextInt(WIDTH - HOOP_SIZE);
            hy = random.nextInt(HEIGHT / 2 - HOOP_SIZE) + HOOP_SIZE;

            // Reset the ball position and velocity and shooting flag
            bx = WIDTH / 2 - BALL_SIZE / 2;
            by = HEIGHT - BALL_SIZE;
            vx = vy = 0;
            shooting = false;
        }
    }

    // Paint method to draw the graphics
    public void paint(Graphics g) {
        super.paint(g);

        // Draw the ball as a red circle
        g.setColor(Color.RED);
        g.fillOval(bx, by, BALL_SIZE, BALL_SIZE);

        // Draw the hoop as a black rectangle
        g.setColor(Color.BLACK);
        g.drawRect(hx, hy, HOOP_SIZE, HOOP_SIZE);
    }
	public void checkWin(){
		if(score > randScore){ //If the users score is higher than the computer generated score then we add a championship image and print that the user won
			chipwin.setBounds(0,0,225,225);
			panel.add(chipwin);
			System.out.println("YOU WON THE CHIP GG!");
		}
	}
}
